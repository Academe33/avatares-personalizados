/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { useLiveAPIContext } from '@/contexts/LiveAPIContext';
import { Agent, createNewAgent } from '@/lib/presets/agents';
import { useAgent, useUI, useUser } from '@/lib/state';
import c from 'classnames';
import { useEffect, useState, MouseEvent, useRef } from 'react';

export default function Header() {
  const { showUserConfig, setShowUserConfig, setShowAgentEdit, setShowPersonaCreationScreen } = useUI();
  const { name: userName } = useUser();
  const { current, setCurrent, availablePresets, availablePersonal, addAgent } =
    useAgent();
  const { disconnect } = useLiveAPIContext();

  const [showRoomList, setShowRoomList] = useState(false);
  const roomListRef = useRef<HTMLDivElement>(null);
  const roomInfoButtonRef = useRef<HTMLButtonElement>(null);


  useEffect(() => {
    const handleClickOutside = (event: globalThis.MouseEvent) => {
      if (
        roomListRef.current &&
        !roomListRef.current.contains(event.target as Node) &&
        roomInfoButtonRef.current &&
        !roomInfoButtonRef.current.contains(event.target as Node)
      ) {
        setShowRoomList(false);
      }
    };
    if (showRoomList) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showRoomList]);

  function changeAgent(agent: Agent | string) {
    disconnect();
    setCurrent(agent);
  }

  function addNewChatterBot() {
    disconnect();
    const newBot = createNewAgent({ name: 'Novo ChatterBot' });
    addAgent(newBot);
    setShowAgentEdit(true); 
  }

  function handleSwitchToPersonaCreation(event: MouseEvent<HTMLButtonElement>) {
    event.stopPropagation();
    disconnect();
    setShowPersonaCreationScreen(true);
    setShowRoomList(false); // Close dropdown
  }


  return (
    <header>
      <div className="roomInfo">
        <div className="roomName">
          <button
            ref={roomInfoButtonRef}
            onClick={(e: MouseEvent<HTMLButtonElement>) => {
              e.stopPropagation();
              setShowRoomList(!showRoomList);
            }}
            aria-expanded={showRoomList}
            aria-controls="agent-list-popup"
            className="button-reset" /* Optional: create a class to reset button styles if h1 is primary content */
            style={{background: 'transparent', border: 'none', padding: 0, color: 'inherit'}}
            aria-label={`Agente atual: ${current?.name || 'Nenhum'}. Clique para mudar.`}
          >
            <h1 className={c({ active: showRoomList })}>
              {current?.name || 'Carregando...'}
              <span className="icon" aria-hidden="true">arrow_drop_down</span>
            </h1>
          </button>

          <button
            onClick={(e: MouseEvent<HTMLButtonElement>) => {
              e.stopPropagation();
              if (current) { 
                setShowAgentEdit(true);
              }
            }}
            className="button createButton" // Uses .button styles by default, createButton for specifics
            disabled={!current}
            aria-label="Editar o ChatterBot atual"
          >
            <span className="icon" aria-hidden="true">edit</span> Editar
          </button>
        </div>

        <div id="agent-list-popup" ref={roomListRef} className={c('roomList', { active: showRoomList })} role="menu" aria-label="Lista de Agentes">
          <div>
            <h3 id="presets-heading">Predefinidos</h3>
            <ul role="group" aria-labelledby="presets-heading">
              {availablePresets
                .filter(agent => agent.id !== current?.id)
                .map(agent => (
                  <li
                    key={agent.id}
                    className={c({ active: agent.id === current?.id })}
                    role="menuitem"
                  >
                    <button onClick={(e: MouseEvent<HTMLButtonElement>) => { e.stopPropagation(); changeAgent(agent); setShowRoomList(false);}}>
                      {agent.name}
                    </button>
                  </li>
                ))}
                {availablePresets.length === 0 && <li role="none"><p style={{padding: '8px 12px', color: 'var(--text-secondary)'}}>Nenhum disponível.</p></li>}
            </ul>
          </div>

          <div>
            <h3 id="your-chatterbots-heading">Seus ChatterBots</h3>
            <ul role="group" aria-labelledby="your-chatterbots-heading">
              {availablePersonal.length > 0 ? (
                availablePersonal
                  .filter(agent => agent.id !== current?.id)
                  .map(({ id, name }) => (
                  <li key={id} className={c({ active: id === current?.id })} role="menuitem">
                    <button onClick={(e: MouseEvent<HTMLButtonElement>) => { e.stopPropagation(); changeAgent(id); setShowRoomList(false);}}>{name}</button>
                  </li>
                ))
              ) : (
                <li role="none"><p style={{padding: '8px 12px', color: 'var(--text-secondary)'}}>Nenhum ainda. Crie um abaixo!</p></li>
              )}
            </ul>
            <button
              className="button newRoomButton"
              onClick={(e: MouseEvent<HTMLButtonElement>) => { e.stopPropagation(); addNewChatterBot(); setShowRoomList(false);}}
              role="menuitem"
            >
              <span className="icon" aria-hidden="true">add_circle</span>Novo Manual
            </button>
             <button
              className="button newRoomButton"
              style={{marginTop: '10px', background: 'var(--accent-green)', color: 'white', borderColor: 'var(--accent-green)'}}
              onClick={handleSwitchToPersonaCreation}
              role="menuitem"
            >
              <span className="icon" aria-hidden="true">person_search</span>Criar Persona (Wikipedia)
            </button>
          </div>
        </div>
      </div>
      <button
        className="userSettingsButton"
        onClick={(e: MouseEvent<HTMLButtonElement>) => {
            e.stopPropagation();
            setShowUserConfig(!showUserConfig);
        }}
        aria-label="Abrir configurações do usuário"
        aria-expanded={showUserConfig}
      >
        <span className="icon" aria-hidden="true">settings</span> {userName || 'Usuário'}
      </button>
    </header>
  );
}