/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useCallback } from 'react';
import { useAgent, useUI, useUser } from '@/lib/state';
import { AGENT_COLORS, Agent, FEMININE_VOICES, INTERLOCUTOR_VOICE, MASCULINE_VOICES, createNewAgent } from '@/lib/presets/agents';
import Modal from './Modal'; // Assuming Modal can be used for the whole screen or part of it.

const WIKIPEDIA_API_URL = 'https://pt.wikipedia.org/w/api.php';

// Helper to pick a random item from an array
const getRandomItem = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

// Basic gender inference (can be improved)
const inferGender = (name: string, text: string): 'female' | 'male' | 'unknown' => {
  const lowerText = text.toLowerCase();
  const lowerName = name.toLowerCase();
  const firstNamePart = lowerName.split(' ')[0];

  const femalePatterns = [
    /\bela\b/g, /\bdela\b/g, new RegExp(`\\ba ${firstNamePart}\\b`, 'g'),
    /\birmã\b/g, /\bmãe\b/g, /\bfilha\b/g, /\besposa\b/g, /\bsenhora\b/g,
    /\batriz\b/g, /\bcantora\b/g, /\bescritora\b/g, /\bpintora\b/g, /\brainha\b/g, /\bprincesa\b/g
  ];
  const malePatterns = [
    /\bele\b/g, /\bdele\b/g, new RegExp(`\\bo ${firstNamePart}\\b`, 'g'),
    /\birmão\b/g, /\bpai\b/g, /\bfilho\b/g, /\besposo\b/g, /\bsenhor\b/g,
    /\bator\b/g, /\bcantor\b/g, /\bescritor\b/g, /\bpintor\b/g, /\brei\b/g, /\bpríncipe\b/g
  ];

  let femaleScore = 0;
  let maleScore = 0;

  femalePatterns.forEach(pattern => {
    const matches = lowerText.match(pattern);
    if (matches) femaleScore += matches.length;
  });
  malePatterns.forEach(pattern => {
    const matches = lowerText.match(pattern);
    if (matches) maleScore += matches.length;
  });

  // Heuristics based on common Portuguese name endings
  if (lowerName.endsWith('a') || lowerName.endsWith('ine') || lowerName.endsWith('ele') || lowerName.endsWith('ite') || lowerName.endsWith('ice')) femaleScore += 2;
  if (lowerName.endsWith('o') || lowerName.endsWith('or') || lowerName.endsWith('ão') || lowerName.endsWith('el') || lowerName.endsWith('ir')) maleScore += 2;


  if (femaleScore > maleScore) return 'female';
  if (maleScore > femaleScore) return 'male';
  return 'unknown';
};


export default function PersonaCreationScreen() {
  const { addAgent, setCurrent } = useAgent();
  const { setShowPersonaCreationScreen } = useUI();
  const [personaName, setPersonaName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { name: userName, info: userInfo, setName: setUserName, setInfo: setUserInfo } = useUser();
  
  const [currentStep, setCurrentStep] = useState<'persona' | 'user'>('persona'); 

  const userNameInputRef = React.useRef<HTMLInputElement>(null);
  const personaNameInputRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (currentStep === 'user' && userNameInputRef.current) {
      userNameInputRef.current.focus();
    } else if (currentStep === 'persona' && personaNameInputRef.current) {
      personaNameInputRef.current.focus();
    }
  }, [currentStep]);

  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() && currentStep === 'user') { 
        setError("Por favor, insira seu nome para continuar.");
        return;
    }
    setError(null);
    setShowPersonaCreationScreen(false); 
  };


  const handlePersonaSearch = async () => {
    if (!personaName.trim()) {
      setError('Por favor, insira o nome de uma pessoa para pesquisar.');
      return;
    }
    setIsLoading(true);
    setError(null);

    let finalPageData: any = null;
    let searchedTitleAttempt = personaName; 

    try {
      // Wikipedia API parameters - common for all queries
      const baseParams = {
        action: 'query',
        format: 'json',
        prop: 'extracts|pageimages|info', // Get extract, page image, and page info (like URL)
        inprop: 'url',         // Ensure canonicalurl is included in page info
        exintro: 'true',       // Get only the introductory section
        explaintext: 'true',   // Get plain text extract
        redirects: '1',        // Automatically follow redirects
        piprop: 'original|thumbnail', // Request 'original' for better quality, fallback to 'thumbnail'
        pithumbsize: '500',    // Request a larger thumbnail size if 'original' isn't available or suitable
        origin: '*',           // CORS
      };
      
      // 1. Attempt direct title query
      const directTitleParams = new URLSearchParams({
        ...baseParams,
        titles: personaName,
      });

      let response = await fetch(`${WIKIPEDIA_API_URL}?${directTitleParams.toString()}`);
      if (!response.ok) {
        throw new Error(`Erro na API da Wikipedia (busca direta): ${response.statusText}`);
      }
      let data = await response.json();
      let pages = data.query.pages;
      let pageId = Object.keys(pages)[0];

      if (pageId && pageId !== '-1' && pages[pageId].extract) {
        finalPageData = pages[pageId];
        searchedTitleAttempt = pages[pageId].title || personaName;
      } else {
        // 2. If direct title fails or lacks extract, attempt a search query
        console.log(`Busca direta por "${personaName}" falhou ou sem extrato. Tentando busca de fallback.`);
        const searchParams = new URLSearchParams({
          action: 'query',
          format: 'json',
          list: 'search',
          srsearch: personaName,
          srlimit: '1', 
          origin: '*',
        });
        response = await fetch(`${WIKIPEDIA_API_URL}?${searchParams.toString()}`);
        if (!response.ok) {
          throw new Error(`Erro na API da Wikipedia (pesquisa): ${response.statusText}`);
        }
        data = await response.json();
        
        if (data.query.search && data.query.search.length > 0) {
          const firstSearchResultTitle = data.query.search[0].title;
          searchedTitleAttempt = firstSearchResultTitle; 
          console.log(`Busca de fallback encontrou: "${firstSearchResultTitle}". Buscando detalhes...`);
          
          // 3. Fetch details for the first search result's title
          const detailsParams = new URLSearchParams({
            ...baseParams,
            titles: firstSearchResultTitle,
          });
          response = await fetch(`${WIKIPEDIA_API_URL}?${detailsParams.toString()}`);
          if (!response.ok) {
            throw new Error(`Erro na API da Wikipedia (detalhes para resultado da busca): ${response.statusText}`);
          }
          data = await response.json();
          pages = data.query.pages;
          pageId = Object.keys(pages)[0];

          if (pageId && pageId !== '-1' && pages[pageId].extract) {
            finalPageData = pages[pageId];
          } else {
            throw new Error(`Nenhuma informação detalhada (com extrato) encontrada para "${firstSearchResultTitle}" (resultado da busca) na Wikipedia.`);
          }
        } else {
          throw new Error(`Nenhum resultado encontrado para "${personaName}" na Wikipedia, mesmo após busca ampla.`);
        }
      }

      if (!finalPageData || !finalPageData.extract) {
         throw new Error(`Não foi possível obter dados válidos (com extrato) da página para "${searchedTitleAttempt}" após todas as tentativas.`);
      }

      const knowledge = finalPageData.extract;
      const officialName = finalPageData.title || searchedTitleAttempt; 
      
      // Prioritize 'original' image source if available, otherwise use 'thumbnail'.
      // Note: Guaranteeing a "human face photo" is beyond Wikipedia API's direct capability.
      // This fetches the best representative *page image* Wikipedia provides.
      const imageUrl = finalPageData.original?.source || finalPageData.thumbnail?.source;


      const gender = inferGender(officialName, knowledge);
      let voice: INTERLOCUTOR_VOICE;
      if (gender === 'female') {
        voice = getRandomItem(FEMININE_VOICES);
      } else if (gender === 'male') {
        voice = getRandomItem(MASCULINE_VOICES);
      } else {
        voice = getRandomItem([...FEMININE_VOICES, ...MASCULINE_VOICES]);
      }
      
      const personalitySummary = `Autêntica personalidade de ${officialName}, baseada em informações biográficas e realizações conhecidas. Aja como se fosse ${officialName} em todos os momentos.`;

      const newPersonaAgent: Agent = createNewAgent({
        name: officialName,
        personality: personalitySummary,
        knowledge: knowledge,
        bodyColor: getRandomItem(AGENT_COLORS), // Color is a fallback if image doesn't load or for abstract avatar parts
        voice: voice,
        imageUrl: imageUrl,
      });

      addAgent(newPersonaAgent);
      setCurrent(newPersonaAgent.id);
      setCurrentStep('user');

    } catch (err) {
      console.error("Erro detalhado:", err);
      const displayError = (err as Error).message.includes(searchedTitleAttempt) 
                           ? (err as Error).message 
                           : `Erro ao processar "${personaName}" (tentativa: "${searchedTitleAttempt}"): ${(err as Error).message}`;
      setError(displayError || 'Ocorreu um erro desconhecido.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSkipPersona = () => {
    // Optionally, set a default predefined agent if desired, or just proceed to user info.
    // For now, just proceeds to user info, and the app will use its default initial agent.
    setCurrentStep('user');
  };
  

  if (currentStep === 'persona') {
    return (
      <div className="modalShroud">
        <div className="modal persona-creation-modal" style={{minWidth: 'clamp(320px, 90vw, 650px)', textAlign: 'center'}}>
          <h2>Com quem você gostaria de conversar?</h2>
          <p style={{margin: "20px 0 30px"}}>
            Digite o nome de uma pessoa famosa ou figura histórica.
            Nós buscaremos informações na Wikipedia para criar um ChatterBot!
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', alignItems: 'stretch', marginBottom: '20px' }}>
            <input
              type="text"
              ref={personaNameInputRef}
              value={personaName}
              onChange={(e) => setPersonaName(e.target.value)}
              placeholder="Ex: Albert Einstein, Cleópatra, Ada Lovelace"
              disabled={isLoading}
              className="largeInput" // Uses global form .largeInput styling
              style={{textAlign: 'center', marginBottom: '10px'}}
              onKeyDown={(e) => { if (e.key === 'Enter' && !isLoading) handlePersonaSearch(); }}
              aria-label="Nome da persona para pesquisar na Wikipedia"
            />
            <button onClick={handlePersonaSearch} disabled={isLoading} className="button primary">
              {isLoading ? (
                <>
                  <span className="icon spin" aria-hidden="true">progress_activity</span>
                  Buscando...
                </>
              ) : (
                <>
                 <span className="icon" aria-hidden="true">search</span> Buscar Persona
                </>
              )}
            </button>
          </div>
          {error && <p role="alert" style={{ color: 'var(--accent-red)', marginTop: '15px', whiteSpace: 'pre-wrap', fontSize: '0.9rem' }}>{error}</p>}
           <button 
              onClick={handleSkipPersona} 
              className="button" 
              style={{marginTop: '25px', background: 'var(--background-elevated)', borderColor: 'var(--border-color)'}}
              disabled={isLoading}
          >
              Pular e usar bots predefinidos
          </button>
        </div>
      </div>
    );
  }

  if (currentStep === 'user') {
    return (
      <div className="modalShroud">
        <div className="modal persona-creation-modal" style={{minWidth: 'clamp(320px, 90vw, 600px)'}}>
          <h2 style={{textAlign: 'center'}}>Bem-vindo(a) ao ChatterBots!</h2>
          <p style={{textAlign: 'center', marginBottom: '25px'}}>Agora, algumas informações sobre você para personalizar a conversa.</p>
          <form onSubmit={handleUserSubmit}>
            <div>
              <label htmlFor="userNameSetup">Seu Nome:</label>
              <input
                id="userNameSetup"
                type="text"
                ref={userNameInputRef}
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="Como podemos te chamar?"
                className="largeInput" // Consistent styling
              />
            </div>
            <div>
              <label htmlFor="userInfoSetup">Sobre Você (opcional):</label>
              <textarea
                id="userInfoSetup"
                rows={4} // Slightly more rows
                value={userInfo}
                onChange={(e) => setUserInfo(e.target.value)}
                placeholder="Interesses, hobbies, o que você gostaria que o ChatterBot soubesse sobre você?"
              />
            </div>
            {error && <p role="alert" style={{ color: 'var(--accent-red)', marginTop: '10px', textAlign: 'center' }}>{error}</p>}
            <button type="submit" className="button primary" style={{marginTop: '10px'}}>
              Concluir e Conversar!
            </button>
          </form>
        </div>
      </div>
    );
  }
  
  return null; 
}