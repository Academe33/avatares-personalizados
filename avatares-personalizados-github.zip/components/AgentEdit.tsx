/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { useRef } from 'react';
import {
  Agent,
  AGENT_COLORS,
  INTERLOCUTOR_VOICE,
  INTERLOCUTOR_VOICES,
} from '@/lib/presets/agents';
import Modal from './Modal';
import c from 'classnames';
import { useAgent, useUI } from '@/lib/state';
import BasicFace from './demo/basic-face/BasicFace'; // Import BasicFace

export default function EditAgent() {
  const agent = useAgent(state => state.current);
  const updateAgent = useAgent(state => state.update);
  const nameInput = useRef<HTMLInputElement>(null);
  const { setShowAgentEdit } = useUI();
  const faceCanvasRef = useRef<HTMLCanvasElement>(null);


  function onClose() {
    setShowAgentEdit(false);
  }

  function updateCurrentAgent(adjustments: Partial<Agent>) {
    if (agent) {
      updateAgent(agent.id, adjustments);
    }
  }

  if (!agent) {
    return (
      <Modal onClose={onClose}>
        <p>Nenhum agente selecionado para edição.</p>
      </Modal>
    );
  }

  return (
    <Modal onClose={onClose}>
      <h2 style={{textAlign: 'center', marginTop: 0}}>Editar Agente: {agent.name}</h2>
      <div className="editAgent">
        <div className="editAgent-form-container">
          <form onSubmit={(e) => { e.preventDefault(); onClose(); }}>
            <div>
              {/* <label htmlFor="agentName">Nome do Agente</label> */}
              <input
                id="agentName"
                className="largeInput" // For prominent name input
                type="text"
                placeholder="Nome do Agente"
                value={agent.name}
                onChange={e => updateCurrentAgent({ name: e.target.value })}
                ref={nameInput}
                aria-label="Nome do Agente"
              />
            </div>

            <div>
              <label htmlFor="agentPersonality">
                Personalidade / Instruções Principais
              </label>
              <textarea
                id="agentPersonality"
                value={agent.personality}
                onChange={e =>
                  updateCurrentAgent({ personality: e.target.value })
                }
                rows={6} // Increased rows
                placeholder="Como devo agir? Qual meu propósito? Descreva minha personalidade e estilo de fala."
                aria-label="Personalidade do Agente"
              />
            </div>

            <div>
              <label htmlFor="agentKnowledge">
                Base de Conhecimento (Detalhes Adicionais)
              </label>
              <textarea
                id="agentKnowledge"
                value={agent.knowledge}
                onChange={e =>
                  updateCurrentAgent({ knowledge: e.target.value })
                }
                rows={10} // Increased rows
                placeholder="Detalhes sobre quem eu sou, o que sei, minhas memórias, experiências e informações específicas que devo conhecer."
                aria-label="Base de Conhecimento do Agente"
              />
            </div>
             <button type="submit" className="button primary" style={{marginTop: '20px', width: '100%'}}>
                Concluir Edição
            </button>
          </form>
        </div>

        <div className="editAgent-controls-preview">
          <p>Cor do Avatar (usado se não houver imagem)</p>
          <ul className="colorPicker" role="radiogroup" aria-label="Seletor de cor do avatar">
            {AGENT_COLORS.map((color, i) => (
              <li
                key={i}
                className={c({ active: color === agent.bodyColor })}
                role="radio"
                aria-checked={color === agent.bodyColor}
                tabIndex={0} // Make all selectable by keyboard
                onClick={() => updateCurrentAgent({ bodyColor: color })}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') {e.preventDefault(); updateCurrentAgent({ bodyColor: color });}}}
              >
                <button // This button is purely for visual presentation of color
                  type="button"
                  style={{ backgroundColor: color }}
                  aria-label={`Cor ${i + 1}: ${color}`}
                  tabIndex={-1} // Not focusable itself, parent li is focusable
                />
              </li>
            ))}
          </ul>
          <div className="agentPreview">
            <BasicFace
                canvasRef={faceCanvasRef}
                color={agent.bodyColor}
                imageUrl={agent.imageUrl}
                radius={100} // Smaller radius for preview
              />
          </div>
          <div className="voicePicker">
            <label htmlFor="agentVoice">Voz do Agente</label>
            <select
              id="agentVoice"
              value={agent.voice}
              onChange={e => {
                updateCurrentAgent({
                  voice: e.target.value as INTERLOCUTOR_VOICE,
                });
              }}
              aria-label="Seletor de voz do agente"
            >
              {INTERLOCUTOR_VOICES.map(voice => (
                <option key={voice} value={voice}>
                  {voice}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </Modal>
  );
}