/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { useLiveAPIContext } from '@/contexts/LiveAPIContext';
import React, { useEffect, useState } from 'react';

export interface ExtendedErrorType {
  code?: number;
  message?: string;
  status?: string;
}

export default function ErrorScreen() {
  const { client } = useLiveAPIContext();
  const [error, setError] = useState<{ message?: string } | null>(null);

  useEffect(() => {
    function onError(errorEvent: ErrorEvent) {
      console.error("Evento de erro recebido:", errorEvent);
      setError({ message: errorEvent.message });
    }

    client.on('error', onError);

    return () => {
      client.off('error', onError);
    };
  }, [client]);

  const quotaErrorMessage =
    'A API Gemini Live no AI Studio tem uma cota gratuita limitada por dia. Volte amanhã para continuar.';

  let errorMessage = 'Algo deu errado. Por favor, tente novamente.';
  let rawMessage: string | null = error?.message || null;
  let tryAgainOption = true;

  if (error?.message) {
    if (error.message.includes('RESOURCE_EXHAUSTED') || error.message.includes('Quota exceeded')) {
      errorMessage = quotaErrorMessage;
      rawMessage = null;
      tryAgainOption = false;
    } else if (error.message.toLowerCase().includes('authentication failed') || error.message.includes('API key not valid')) {
      errorMessage = 'Falha na autenticação. Verifique sua chave de API.';
      rawMessage = `Detalhe: ${error.message}`;
      tryAgainOption = false; // Usually, closing won't fix an API key issue
    } else {
      // Use the generic message but provide the raw error for debugging
      errorMessage = 'Ocorreu um erro inesperado.';
      rawMessage = `Detalhe: ${error.message}`;
    }
  }


  if (!error) {
    return <div style={{ display: 'none' }} aria-hidden="true" />;
  }

  return (
    <div className="error-screen" role="alertdialog" aria-labelledby="error-title" aria-describedby="error-desc">
      <div
        style={{
          fontSize: 48,
        }}
        aria-hidden="true"
      >
        💔
      </div>
      <h2 id="error-title" style={{ opacity: 0.8, fontSize: 28 }}>Ops! Um Erro Ocorreu.</h2>
      <div
        id="error-desc"
        className="error-message-container"
        style={{
          fontSize: 20,
          lineHeight: 1.3,
          opacity: 0.6,
          marginTop: '10px',
          marginBottom: '20px',
        }}
      >
        {errorMessage}
      </div>
      {tryAgainOption ? (
        <button
          className="button primary"
          style={{ padding: '10px 20px' }}
          onClick={() => {
            setError(null);
            // Potentially add a reload or retry logic here if applicable
          }}
        >
          Fechar
        </button>
      ) : null}
      {rawMessage && (
        <div
          className="error-raw-message-container"
          style={{
            fontSize: 14,
            lineHeight: 1.2,
            opacity: 0.5,
            marginTop: '20px',
            background: 'var(--Neutral-10)',
            padding: '10px',
            borderRadius: '8px',
            maxWidth: '80%',
            wordBreak: 'break-all',
          }}
        >
          <strong>Detalhes Técnicos:</strong> <pre style={{whiteSpace: 'pre-wrap'}}>{rawMessage}</pre>
        </div>
      )}
    </div>
  );
}