/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { RefObject, useEffect, useState, useRef } from 'react';

import { renderBasicFace } from './basic-face-render';

import useFace from '../../../hooks/demo/use-face';
import useHover from '../../../hooks/demo/use-hover';
import useTilt from '../../../hooks/demo/use-tilt';
import { useLiveAPIContext } from '../../../contexts/LiveAPIContext';

// Minimum volume level that indicates audio output is occurring
const AUDIO_OUTPUT_DETECTION_THRESHOLD = 0.05;

// Amount of delay between end of audio output and setting talking state to false
const TALKING_STATE_COOLDOWN_MS = 2000;

type BasicFaceProps = {
  /** The canvas element on which to render the face. Only used if imageUrl is not provided. */
  canvasRef?: RefObject<HTMLCanvasElement | null>;
  /** The radius of the face. */
  radius?: number;
  /** The color of the face (for canvas fallback). */
  color?: string;
  /** Optional URL for an image to display as the avatar. */
  imageUrl?: string;
};

export default function BasicFace({
  canvasRef,
  radius = 250,
  color,
  imageUrl,
}: BasicFaceProps) {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null); // Corrected type for timeoutRef

  // Audio output volume
  const { volume } = useLiveAPIContext();

  // Talking state
  const [isTalking, setIsTalking] = useState(false);

  const [scale, setScale] = useState(1);

  // Face state
  const { eyeScale, mouthScale } = useFace();
  const hoverPosition = useHover();
  const tiltAngle = useTilt({
    maxAngle: 5,
    speed: 0.075,
    isActive: isTalking,
  });

  useEffect(() => {
    function calculateScale() {
      setScale(Math.min(window.innerWidth, window.innerHeight) / 1000);
    }
    window.addEventListener('resize', calculateScale);
    calculateScale();
    return () => window.removeEventListener('resize', calculateScale);
  }, []);

  // Detect whether the agent is talking based on audio output volume
  // Set talking state when volume is detected
  useEffect(() => {
    if (volume > AUDIO_OUTPUT_DETECTION_THRESHOLD) {
      setIsTalking(true);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout( // Assign to timeoutRef.current
        () => setIsTalking(false),
        TALKING_STATE_COOLDOWN_MS
      );
    }
  }, [volume]);

  // Render the face on the canvas if no imageUrl
  useEffect(() => {
    if (!imageUrl && canvasRef?.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        renderBasicFace({ ctx, mouthScale, eyeScale, color });
      }
    }
  }, [canvasRef, volume, eyeScale, mouthScale, color, scale, imageUrl]);

  const commonStyle = {
    display: 'block',
    transform: `translateY(${hoverPosition}px) rotate(${tiltAngle}deg)`,
    width: radius * 2 * scale,
    height: radius * 2 * scale,
  };

  if (imageUrl) {
    return (
      <img
        src={imageUrl}
        alt="Avatar"
        className="basic-face-image"
        style={{
          ...commonStyle,
          borderRadius: '50%',
          objectFit: 'cover',
          boxShadow: '0px 0px 30px -10px var(--accent-blue)', // Optional: mimic canvas glow
        }}
      />
    );
  } else {
    return (
      <canvas
        className="basic-face-canvas"
        ref={canvasRef}
        width={radius * 2 * scale}
        height={radius * 2 * scale}
        style={commonStyle}
        aria-label="Avatar animado abstrato"
      />
    );
  }
}