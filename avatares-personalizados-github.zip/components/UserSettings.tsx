/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import Modal from './Modal';
import { useUI, useUser } from '@/lib/state';

export default function UserSettings() {
  const { name, info, setName, setInfo } = useUser();
  const { setShowUserConfig } = useUI();

  function updateClientAndClose() {
    // Future: If client-side updates beyond UI are needed, they go here.
    setShowUserConfig(false);
  }

  return (
    <Modal onClose={() => setShowUserConfig(false)}>
      <div className="userSettings"> {/* This class can now target the content area */}
        <h2 style={{textAlign: 'center', marginTop: 0}}>Configurações do Usuário</h2>
        <p style={{textAlign: 'center', marginBottom: '24px'}}>
          Personalize suas informações para tornar as conversas com os ChatterBots mais envolventes.
        </p>

        <form
          onSubmit={e => {
            e.preventDefault();
            updateClientAndClose();
          }}
        >
          <div>
            <label htmlFor="userName">Seu nome</label>
            <input
              id="userName"
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Como você gostaria de ser chamado(a)?"
              className="largeInput" // For a more prominent name input
            />
          </div>

          <div>
            <label htmlFor="userInfo">Suas informações (opcional)</label>
            <textarea
              id="userInfo"
              rows={5} // Increased rows for more space
              value={info}
              onChange={e => setInfo(e.target.value)}
              placeholder="Coisas que os ChatterBots devem saber sobre você... Seus gostos, desgostos, hobbies, interesses, ou qualquer coisa que ajude a personalizar a conversa."
            />
          </div>

          <button type="submit" className="button primary" style={{width: '100%'}}>Salvar e Fechar</button>
        </form>
      </div>
    </Modal>
  );
}