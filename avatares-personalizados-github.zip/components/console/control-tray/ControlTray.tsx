/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/**
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import cn from 'classnames';

import { memo, ReactNode, useEffect, useRef, useState } from 'react';
import { AudioRecorder } from '../../../lib/audio-recorder';

import { useLiveAPIContext } from '../../../contexts/LiveAPIContext';
import { useUI } from '@/lib/state';

export type ControlTrayProps = {
  children?: ReactNode;
};

function ControlTray({ children }: ControlTrayProps) {
  const [audioRecorder] = useState(() => new AudioRecorder());
  const [isMuted, setIsMuted] = useState(true); // Start muted
  const connectButtonRef = useRef<HTMLButtonElement>(null);
  const micButtonRef = useRef<HTMLButtonElement>(null);


  const { showAgentEdit, showUserConfig, showPersonaCreationScreen } = useUI();
  const { client, connected, connect, disconnect } = useLiveAPIContext();

  // Stop the current agent if the user is editing the agent or user config, or on persona creation screen
  useEffect(() => {
    if (showAgentEdit || showUserConfig || showPersonaCreationScreen) {
      if (connected) disconnect();
      if (!isMuted && audioRecorder.recording) audioRecorder.stop();
    }
  }, [showUserConfig, showAgentEdit, showPersonaCreationScreen, connected, disconnect, isMuted, audioRecorder]);

  // Focus management
  useEffect(() => {
    if (!connected && connectButtonRef.current) {
      // connectButtonRef.current.focus(); // Auto-focus can be disruptive; consider user intent
    }
  }, [connected]);

  // Audio recording logic
  useEffect(() => {
    const onData = (base64: string) => {
      client.sendRealtimeInput([
        {
          mimeType: 'audio/pcm;rate=16000',
          data: base64,
        },
      ]);
    };
    const onVolume = (volume: number) => {
        if(micButtonRef.current){
            micButtonRef.current.style.setProperty('--volume', (volume * 50) + 'px');
        }
    }

    if (connected && !isMuted && audioRecorder) {
      audioRecorder.on('data', onData);
      audioRecorder.on('volume', onVolume);
      if (!audioRecorder.recording) {
        audioRecorder.start().catch(err => console.error("Failed to start audio recorder:", err));
      }
    } else {
      if (audioRecorder.recording) {
        audioRecorder.stop();
      }
      audioRecorder.off('data', onData);
      audioRecorder.off('volume', onVolume);
      if(micButtonRef.current) micButtonRef.current.style.setProperty('--volume', '0px');
    }
    return () => { // Cleanup
      if (audioRecorder.recording) {
        audioRecorder.stop();
      }
      audioRecorder.off('data', onData);
      audioRecorder.off('volume', onVolume);
    };
  }, [connected, client, isMuted, audioRecorder]);


  const handleMicToggle = () => {
    if (!connected) return; // Mic only works when connected
    setIsMuted(!isMuted);
  };

  return (
    <section className="control-tray" aria-label="Controles de streaming e áudio">
      <nav className={cn('actions-nav')} aria-label="Ações de áudio">
        <button
          ref={micButtonRef}
          className={cn('action-button mic-button', { muted: isMuted || !connected })}
          onClick={handleMicToggle}
          aria-pressed={!isMuted && connected}
          aria-label={isMuted || !connected ? "Ativar microfone (requer conexão)" : "Desativar microfone"}
          disabled={!connected} // Disable if not connected
        >
          <span className="icon" aria-hidden="true">{isMuted || !connected ? 'mic_off' : 'mic'}</span>
        </button>
        {children}
      </nav>

      <div className={cn('connection-container', { connected })}>
         <button
            ref={connectButtonRef}
            className={cn('action-button connect-toggle', { connected })}
            onClick={connected ? disconnect : connect}
            aria-pressed={connected}
            aria-label={connected ? "Desconectar streaming" : "Conectar streaming e iniciar conversa"}
          >
            <span className="icon" aria-hidden="true">
              {connected ? 'pause' : 'play_arrow'}
            </span>
          </button>
        <span className="text-indicator" aria-live="polite">
          {connected ? 'Conectado' : 'Desconectado'}
        </span>
      </div>
    </section>
  );
}

export default memo(ControlTray);