/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { create } from 'zustand';
import { Agent, Charlotte, Paul, Shane, Penny, createNewAgent } from './presets/agents';

/**
 * User
 */
export type User = {
  name?: string;
  info?: string;
};

export const useUser = create<
  {
    setName: (name: string) => void;
    setInfo: (info: string) => void;
  } & User
>(set => ({
  name: '',
  info: '',
  setName: name => set({ name }),
  setInfo: info => set({ info }),
}));

/**
 * Agents
 */
function getAgentById(id: string) {
  const { availablePersonal, availablePresets } = useAgent.getState();
  return (
    availablePersonal.find(agent => agent.id === id) ||
    availablePresets.find(agent => agent.id === id) ||
    null // Return null if not found
  );
}

export const useAgent = create<{
  current: Agent | null; // Can be null initially
  availablePresets: Agent[];
  availablePersonal: Agent[];
  setCurrent: (agentOrId: Agent | string | null) => void;
  addAgent: (agent: Agent) => void;
  update: (agentId: string, adjustments: Partial<Agent>) => void;
  clearPersonalAgents: () => void;
  getDefaultAgent: () => Agent; // Function to get a default agent
}>(set => ({
  current: null, // Start with no agent selected
  availablePresets: [Paul, Charlotte, Shane, Penny],
  availablePersonal: [],
  getDefaultAgent: () => Paul, // Paul is the default if no other is selected

  addAgent: (agent: Agent) => {
    set(state => ({
      availablePersonal: [...state.availablePersonal, agent],
      current: agent, 
    }));
  },
  setCurrent: (agentOrId: Agent | string | null) =>
    set(state => {
      let newCurrentAgent: Agent | null = null;
      if (agentOrId === null) {
        newCurrentAgent = null;
      } else if (typeof agentOrId === 'string') {
        newCurrentAgent = getAgentById(agentOrId);
      } else {
        newCurrentAgent = agentOrId;
      }
      
      // If newCurrentAgent is still null (e.g., ID not found), 
      // and there's no current agent, set to a default.
      // Otherwise, if an agent is explicitly set to null, allow it.
      if (newCurrentAgent === null && typeof agentOrId === 'string' && !state.current) {
         console.warn(`Agent with ID "${agentOrId}" not found. Falling back to default.`);
         newCurrentAgent = state.getDefaultAgent();
      }

      return { current: newCurrentAgent };
    }),
  update: (agentId: string, adjustments: Partial<Agent>) => {
    set(state => {
      const agentToUpdate = getAgentById(agentId);
      if (!agentToUpdate) return state;

      const updatedAgent = { ...agentToUpdate, ...adjustments };

      return {
        availablePresets: state.availablePresets.map(a =>
          a.id === agentId ? updatedAgent : a
        ),
        availablePersonal: state.availablePersonal.map(a =>
          a.id === agentId ? updatedAgent : a
        ),
        current: state.current?.id === agentId ? updatedAgent : state.current,
      };
    });
  },
  clearPersonalAgents: () => set({ availablePersonal: [] }),
}));

/**
 * UI
 */
export const useUI = create<{
  showPersonaCreationScreen: boolean;
  setShowPersonaCreationScreen: (show: boolean) => void;
  showUserConfig: boolean;
  setShowUserConfig: (show: boolean) => void;
  showAgentEdit: boolean;
  setShowAgentEdit: (show: boolean) => void;
}>(set => ({
  showPersonaCreationScreen: true, // Start with persona creation
  setShowPersonaCreationScreen: (show: boolean) => set({ showPersonaCreationScreen: show }),
  showUserConfig: false, 
  setShowUserConfig: (show: boolean) => set({ showUserConfig: show }),
  showAgentEdit: false,
  setShowAgentEdit: (show: boolean) => set({ showAgentEdit: show }),
}));